package com.myworks.async;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsyncApplicationTests {

	@Test
	void contextLoads() {
	}

}

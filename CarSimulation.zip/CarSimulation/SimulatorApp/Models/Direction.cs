namespace SimulatorApp.Models
{
    public enum Direction
    {
        N = 0,
        S = 1,
        E = 2,
        W = 3
    }
}






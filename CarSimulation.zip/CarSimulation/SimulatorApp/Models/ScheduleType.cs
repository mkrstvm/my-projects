namespace SimulatorApp.Models
{
    public enum ScheduleType
    {
        All,
        Single,
        Batch
    }
}
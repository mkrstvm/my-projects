﻿namespace SimulatorApp
{
    class Program
    {
        static void Main(string[] args)
        {
            AutoDriver driver  = new AutoDriver();
            driver.Start();
        }
    }
}
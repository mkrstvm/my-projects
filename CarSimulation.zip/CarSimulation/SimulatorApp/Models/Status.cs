namespace SimulatorApp.Models
{
    /// <summary>
    /// condition of the car
    /// </summary>
    public enum Status
    {
        Running,
        Collided        
    }
}
namespace SimulatorApp.Models
{
    public enum VehicleType
    {
        Car = 0
    }
}